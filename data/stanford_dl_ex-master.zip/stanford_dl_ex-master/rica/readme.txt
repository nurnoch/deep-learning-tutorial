to get started run runSoftICA.m
you need to download minFunc here:
http://www.di.ens.fr/~mschmidt/Software/minFunc_2009.zip
