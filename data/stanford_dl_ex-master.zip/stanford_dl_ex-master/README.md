stanford_dl_ex
==============

Programming exercises for the Stanford Unsupervised Feature Learning and Deep Learning Tutorial

This repository contains starter code for the tutorial at http://ufldl.stanford.edu/tutorial

If you have suggestions, questions, or bug reports, please submit contact:

Andrew Maas ( amaas AT cs dot stanford.edu)
Sameep Tandon (sameep AT stanford dot edu)
